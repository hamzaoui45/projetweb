<?php
class category{
    private $id_category;
    private $name_category;
    private $description;

    public function __construct($id_category,$name_category,$description)
    {
        $this->id_category=$id_category;
        $this->name_category=$name_category;
        $this->description=$description;
    }
    

    

    /**
     * Get the value of name_categorie
     */ 
    public function getName_category()
    {
        return $this->name_category;
    }

    /**
     * Set the value of name_categorie
     *
     * @return  self
     */ 
    public function setName_category($name_category)
    {
        $this->name_category = $name_category;

        return $this;
    }
    public function getdescription()
    {
        return $this->description;
    }

    /**
     * Set the value of name_categorie
     *
     * @return  self
     */ 
    public function setdescription($description)
    {
        $this->description = $description;

        return $this;
    }
}