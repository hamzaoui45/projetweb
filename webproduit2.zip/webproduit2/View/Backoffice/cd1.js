document.getElementById('pName').addEventListener('keyup', function () {
    const nameProduct = this.value;
    const nameError = document.getElementById('nameError');
    const nameRegex = /^[a-zA-Z\s]+$/;  // Only letters and spaces
    let isValid = true;

    if (nameProduct.trim() === '') {
        nameError.textContent = "The product name cannot be empty.";
        nameError.classList.remove('success');
        nameError.classList.add('error');
        isValid = false;
    } else if (!nameRegex.test(nameProduct)) {
        nameError.textContent = "The product name is invalid. Only letters and spaces allowed.";
        nameError.classList.remove('success');
        nameError.classList.add('error');
        isValid = false;
    } else {
        nameError.textContent = "The product name is valid.";
        nameError.classList.remove('success');
        nameError.classList.add('error');
    }

    validateForm();
});

// Handle real-time validation for Description
document.getElementById('pdescription').addEventListener('keyup', function () {
    const description = this.value;
    const descriptionError = document.getElementById('nameError1');
    const descriptionRegex = /^[a-zA-Z\s]+$/;  // Only letters and spaces
    let isValid = true;

    if (description.trim() === '') {
        descriptionError.textContent = "The description cannot be empty.";
        isValid = false;
    } else if (!descriptionRegex.test(description)) {
        descriptionError.textContent = "The description is invalid. Only letters and spaces allowed.";
        isValid = false;
    } else {
        descriptionError.textContent = "The description is valid.";
    }

    validateForm();
});

// Handle real-time validation for Price
document.getElementById('price').addEventListener('keyup', function () {
    const price = this.value;
    const priceError = document.getElementById('nameError2');
    const priceRegex = /^\d+(\.\d+)?$/;  // Allows numbers and decimal points
    let isValid = true;

    if (price.trim() === '') {
        priceError.textContent = "The price cannot be empty.";
        isValid = false;
    } else if (parseFloat(price) <= 0 || !priceRegex.test(price)) {
        priceError.textContent = "The price must be a positive number.";
        isValid = false;
    } else {
        priceError.textContent = "The price is valid.";
    }

    validateForm();
});

// Handle real-time validation for Category
document.getElementById('category').addEventListener('keyup', function () {
    validateForm();
});

// Validate the form and enable/disable the submit button
function validateForm() {
    const nameProduct = document.getElementById('pName').value.trim();
    const description = document.getElementById('pdescription').value.trim();
    const price = document.getElementById('price').value.trim();
    const category = document.getElementById('category').value.trim();

    const isFormValid = nameProduct && description && price && category && 
        /^[a-zA-Z\s]+$/.test(nameProduct) &&
        /^[a-zA-Z\s]+$/.test(description) &&
        /^\d+(\.\d+)?$/.test(price) && 
        price > 0;

    const submitBtn = document.getElementById('submitBtn');
    if (isFormValid) {
        submitBtn.removeAttribute('disabled');
        submitBtn.classList.remove('disabled');
    } else {
        submitBtn.setAttribute('disabled', 'true');
        submitBtn.classList.add('disabled');
    }
}