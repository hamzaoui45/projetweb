
document.getElementById('pName').addEventListener('keyup', function () {
    const name_category = this.value;
    var nameError = document.getElementById('nameError');
    const nameRegex = /^[a-zA-Z]+$/;  // Regular expression to allow only alphabetic characters

    if (name_category.trim() === '') {
        nameError.textContent = "The name cannot be empty.";
        nameError.classList.remove('success');
        nameError.classList.add('error');
    }
    // Check if the input matches the regex
    else if (!nameRegex.test(name_category)) {
        nameError.textContent = "the name is invalid.";
        nameError.classList.remove('success');
        nameError.classList.add('error');
    } else {
        nameError.textContent = 'the name is valid';
        nameError.classList.remove('error');
        nameError.classList.add('success');
    }
});
document.getElementById('pdescription').addEventListener('keyup', function () {
    const name_category = this.value;
    var nameError = document.getElementById('nameError1');
    const nameRegex =/^[a-zA-Z\s]+$/;  // Regular expression to allow only alphabetic characters

    if (name_category.trim() === '') {
        nameError.textContent = "The description cannot be empty.";
        nameError.classList.remove('success');
        nameError.classList.add('error');
    }
    // Check if the input matches the regex
    else if (!nameRegex.test(name_category)) {
        nameError.textContent = "the description is invalid.";
        nameError.classList.remove('success');
        nameError.classList.add('error');
    } else {
        nameError.textContent = 'the description is valid';
        nameError.classList.remove('error');
        nameError.classList.add('success');
    }
});
document.getElementById('price').addEventListener('keyup', function () {
    const price = this.value;
    var nameError = document.getElementById('nameError2');
    const priceRegex = /^\d+(\.\d+)?$/; 

    // Check if the input is empty
    if (price.trim() === '') {
        nameError.textContent = "The price cannot be empty.";
        nameError.classList.remove('success');
        nameError.classList.add('error');
    }
    // Check if the price is a positive number
    else if (parseFloat(price) <= 0 || !priceRegex.test(price)) {
        nameError.textContent = "The price must be a positive number.";
        nameError.classList.remove('success');
        nameError.classList.add('error');
    } else {
        nameError.textContent = "The price is valid";
        nameError.classList.remove('error');
        nameError.classList.add('success');
    }
});




