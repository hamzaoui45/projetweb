<?php
include 'C:\xampp\htdocs\web2\Controler\categorie.php';
include 'C:\xampp\htdocs\web2\Model\addcategorie.php';


include 'C:\xampp\htdocs\web2\Controler\product.php';

$categoryc = new categorycontroler();



//$category = $categoryc->affichec();



$productC = new productcontroler();
$list = $productC->productList();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>product list</title>
</head>
<body>
    <a href="addproduit.php">Add</a>
        <table border>
        <tr>
            <th>id</th>
            <th>Procuct name</th>
            <th>description</th>
            <th>price</th>
            <th>category</th>
        </tr>
        <?php
        foreach ($list as $product) {
            ?> <tr>
                    <td><?= $product['id_product']; ?></td>
                    <td><?= $product['name_product']; ?></td>
                    <td><?= $product['description']; ?></td>
                    <td><?= $product['price']; ?></td>
                    
                    <td>
                    <?= $product['category'] ?>
                    </td>

                    <td>   
                    <form method="POST" action="updateproduct.php">
                        <input type="submit" name="update" value="Update">
                        <input type="hidden" value=<?PHP echo $product['id_product']; ?> name="id_product">
                    </form>
                    <a href="deleteproduct.php ?id_product=<?= $product['id_product']; ?>">Delete</a>
                    </td>
               </tr>
        <?php
        }
        ?>
        </table>
</body>
</html>