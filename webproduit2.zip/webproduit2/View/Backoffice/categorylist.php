<?php

include 'C:\xampp\htdocs\web2\Controler\categorie.php';
include 'C:\xampp\htdocs\web2\config.php';
$categoryC = new categorycontroler();
$list = $categoryC->categoryList();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>category list</title>
</head>
<body>
    <a href="addcategory.php">Add</a>
        <table border>
        <tr>
            <th>id</th>
            <th>category name</th>
            <th>description</th>
        </tr>
        <?php
        foreach ($list as $category) {
            ?> <tr>
                    <td><?= $category['id_category']; ?></td>
                    <td><?= $category['name_category']; ?></td>
                    <td><?= $category['description']; ?></td>
                    <td>   
                    <form method="POST" action="updatecategory.php">
                        <input type="submit" name="update" value="Update">
                        <input type="hidden" value=<?PHP echo $category['id_category']; ?> name="id_category">
                    </form>
                    <a href="deletecategory.php ?id_category=<?= $category['id_category']; ?>">Delete</a>
                    </td>
               </tr>
        <?php
        }
        ?>
        </table>
</body>
</html>