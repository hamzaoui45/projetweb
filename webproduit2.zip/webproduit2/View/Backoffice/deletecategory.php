<?php
include 'C:\xampp\htdocs\web2\Controler\categorie.php';
include 'C:\xampp\htdocs\web2\config.php';
$categoryC = new categorycontroler();

// récupérer l'id passé dans l'URL en utilisant la methode par défaut $_GET["id"]
$categoryC->deletecategory($_GET["id_category"]);
//une fois la suppression est faite une redirection vers la liste des produits ce fait
header('Location:categorylist.php');

?>