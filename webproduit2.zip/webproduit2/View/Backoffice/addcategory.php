<?php
include 'C:\xampp\htdocs\web2\Controler\categorie.php';
include 'C:\xampp\htdocs\web2\Model\addcategorie.php';
include 'C:\xampp\htdocs\web2\config.php';


if(isset($_POST["pName"]) && isset($_POST["pdescription"])  ) 
{
    if (
        !empty($_POST["pName"]) && !empty($_POST["pdescription"]) 

    ) {
        $category = new category(null,$_POST["pName"],$_POST["pdescription"]);
        $categoryC = new categorycontroler();
        $categoryC->addcategory($category);
        header('Location:categorylist.php');
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add category</title>
    <link rel="stylesheet" href="styles1.css">
    
    <style>
        .error {
            color: red;
        }
        .success {
            color: green;
        }
      
        
    </style>
</head>
<body>
    <header>
        <h1>Add category</h1>
    </header>
    <div class="container">
        <div class="form-box">
            <form method="post" action="">
                <div class="form-group">
                    <label for="pName">Category name:</label>
                    <input type="text" id="pName" name="pName">
                    <h5 id="nameError" class="error"> </h5>
                    
                </div>
                <div class="form-group">
                    <label for="pdescription">Description:</label>
                    <input type="text" id="pdescription" name="pdescription">
                    <h5 id="nameError1" class="error"> </h5>

                </div>
                <div class="form-group">
                    <button type="submit">Enregistrer</button>
                </div>
            </form>
        </div>
    </div>

    <footer>
        <div class="footer-content">
            <p>&copy; 2024 AgriPlate. All rights reserved.</p>
        </div>
    </footer>
    <script src="cd.js"></script>
</body>
</html>

