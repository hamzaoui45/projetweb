<?php
include 'C:\xampp\htdocs\web2\Controler\product.php';

$productC = new productcontroler();

// récupérer l'id passé dans l'URL en utilisant la methode par défaut $_GET["id"]
$productC->deleteproduct($_GET["id_product"]);
//une fois la suppression est faite une redirection vers la liste des produits ce fait
header('Location:productlist.php');

?>