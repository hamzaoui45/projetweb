<?php
include 'C:\xampp\htdocs\web2\Controler\categorie.php';
include 'C:\xampp\htdocs\web2\Model\addcategorie.php';
include 'C:\xampp\htdocs\web2\config.php';
$category = null;
$error = "";
// create an instance of the controller
$categorycontroler = new categorycontroler();

//utiliser la fonction isset() pour vérifier si les clés name, price et category existe avant d'y accéder
if (
    isset($_POST["name_category"])  && isset($_POST["description"])
) {
    //utiliser la fonction empty() pour vérifier si les clés name, price et category posséde des valeurs
    if (
        !empty($_POST["name_category"])  && !empty($_POST["description"]) 
    ) {
        // créer un objet à partir des nouvelles valeurs passées pour mettre à jour le produit choisi
        $category = new category(
            null,
            $_POST['name_category'],
            $_POST['description'],
            /*$_POST['category'],*/
        );
        // appelle de la fonction updateProduct
        $categorycontroler->updatecategory($category, $_POST['id_category']);
        // une fois l'update est faite une redirection vers la page liste des produits sera faite
        header('Location:categorylist.php');
    } else
        // message en cas de manque d'information
        $error = "Missing information";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>updatecategory</title>
    <style>
        .error {
            color: red;
        }
        .success {
            color: green;
        }
    </style>
    

</head>
<body>
<!--<script src="cd.js"></script>-->
<?php
    // $_POST['id'] récupérer à partir du form relative au bouton update dans la page productList
    if (isset($_POST['id_category'])) {
        //récupération du produit à mettre à jour par son ID
        $category = $categorycontroler->getcategoryById($_POST['id_category']);
    ?>
        <!-- remplir le vormulaire par les données du produits à mettre à jour -->
        <form id="category" action="" method="POST">
            

            <label for="id_category">ID category:</label>
            <input class="form-control form-control-user" type="text" id="id_category" name="id_category" readonly value="<?php echo $_POST['id_category'] ?>"><br>
            


            <label for="id_category">category Name </label>
            <input class="form-control form-control-user" type="text" id="name_category" name="name_category" value="<?php echo $category['name_category'] ?>"><br>
            <h5 id="nameError5" class="error"> </h5>

            <label for="title">description</label>
            <input class="form-control form-control-user" type="text" id="description" name="description" value="<?php echo $category['description'] ?>"><br>
            <h5 id="nameError6" class="error"> </h5>
            
            <input type="submit" value="save">
        </form>
    <?php
    }
    ?>
    
</body>
<script>
        document.getElementById('name_category').addEventListener('keyup', function () {
    const name_category = this.value;
    var nameError = document.getElementById('nameError5');
    const nameRegex = /^[a-zA-Z\s]+$/;  // Allow alphabetic characters and spaces

    if (name_category.trim() === '') {
        nameError.textContent = "The name cannot be empty.";
        nameError.classList.remove('success');
        nameError.classList.add('error');
    } else if (!nameRegex.test(name_category)) {
        nameError.textContent = "The name is invalid.";
        nameError.classList.remove('success');
        nameError.classList.add('error');
    } else {
        nameError.textContent = 'The name is valid';
        nameError.classList.remove('error');
        nameError.classList.add('success');
    }
});

document.getElementById('description').addEventListener('keyup', function () {
    const description = this.value;
    var nameError = document.getElementById('nameError6');
    const nameRegex = /^[a-zA-Z\s]+$/;  // Allow alphabetic characters and spaces

    if (description.trim() === '') {
        nameError.textContent = "The description cannot be empty.";
        nameError.classList.remove('success');
        nameError.classList.add('error');
    } else if (!nameRegex.test(description)) {
        nameError.textContent = "The description is invalid.";
        nameError.classList.remove('success');
        nameError.classList.add('error');
    } else {
        nameError.textContent = 'The description is valid';
        nameError.classList.remove('error');
        nameError.classList.add('success');
    }
});
    </script>
</html>