<?php
include 'C:\xampp\htdocs\web2\Controler\product.php';
include 'C:\xampp\htdocs\web2\Model\addproduct.php';


$product = null;
$error = "";
$productC = new productcontroler();

if(isset($_POST["name_product"]) && isset($_POST["description"]) && isset($_POST["price"] ) && isset($_POST["category"]) )
{
    if (
        !empty($_POST["name_product"]) && !empty($_POST["description"]) && !empty($_POST["price"]) && !empty($_POST["category"] ) 

    ) {
        $product = new product(null,$_POST["name_product"],$_POST["description"],$_POST["price"],$_POST["category"]);
        
        $productC->updateproduct($product,$_POST['id_product']);
        header('Location:productlist.php');
    }
    else
    // message en cas de manque d'information
    $error = "Missing information";

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>updatecategory</title>
    <style>
        .error {
            color: red;
        }
        .success {
            color: green;
        }
    </style>
   
</head>
<body>
<!--<script src="cd.js"></script>-->
<?php
    // $_POST['id'] récupérer à partir du form relative au bouton update dans la page productList
    if (isset($_POST['id_product'])) {
        //récupération du produit à mettre à jour par son ID
        $product = $productC->getproductById($_POST['id_product']);
    ?>
        <!-- remplir le vormulaire par les données du produits à mettre à jour -->
        <form id="category" action="" method="POST">
            <label for="id_product">ID product:</label>
            <!-- remplir chaque input par la valeur adéquate dans l'attribut value  -->
            <input class="form-control form-control-user" type="text" id="id_product" name="id_product" readonly value="<?php echo $_POST['id_product'] ?>"><br>

            <label for="id_product">product Name </label>
            <input class="form-control form-control-user" type="text" id="name_product" name="name_product" value="<?php echo $product['name_product'] ?>"><br>
            <h5 id="nameError" class="error"> </h5>
            
            <label for="title">description</label>
            <input class="form-control form-control-user" type="text" id="description" name="description" value="<?php echo $product['description'] ?>"><br>
            <h5 id="descriptionError" class="error"> </h5>

            <label for="title">price</label>
            <input class="form-control form-control-user" type="float" id="price" name="price" value="<?php echo $product['price'] ?>"><br>
            <h5 id="priceError" class="error"> </h5>

            <label for="title">category</label>
            <input class="form-control form-control-user" type="text" id="category" name="category" value="<?php echo $product['category'] ?>"><br>
            <input type="submit" value="save">
        </form>
    <?php
    }
    ?>
</body>
<script>
        document.getElementById('name_product').addEventListener('keyup', function () {
    const name_product = this.value;
    var nameError = document.getElementById('nameError');
    const nameRegex = /^[a-zA-Z\s]+$/;  // Only letters and spaces

    if (name_product.trim() === '') {
        nameError.textContent = "The name cannot be empty.";
        nameError.classList.remove('success');
        nameError.classList.add('error');
    } else if (!nameRegex.test(name_product)) {
        nameError.textContent = "The name is invalid.";
        nameError.classList.remove('success');
        nameError.classList.add('error');
    } else {
        nameError.textContent = 'The name is valid';
        nameError.classList.remove('error');
        nameError.classList.add('success');
    }
});

document.getElementById('description').addEventListener('keyup', function () {
    const description = this.value;
    var descriptionError = document.getElementById('descriptionError');
    const descriptionRegex = /^[a-zA-Z\s]+$/;  // Only letters and spaces

    if (description.trim() === '') {
        descriptionError.textContent = "The description cannot be empty.";
        descriptionError.classList.remove('success');
        descriptionError.classList.add('error');
    } else if (!descriptionRegex.test(description)) {
        descriptionError.textContent = "The description is invalid.";
        descriptionError.classList.remove('success');
        descriptionError.classList.add('error');
    } else {
        descriptionError.textContent = 'The description is valid';
        descriptionError.classList.remove('error');
        descriptionError.classList.add('success');
    }
});

document.getElementById('price').addEventListener('keyup', function () {
    const price = this.value;
    var priceError = document.getElementById('priceError');
    const priceRegex = /^\d+(\.\d+)?$/;  // Allows integers and decimals

    if (price.trim() === '') {
        priceError.textContent = "The price cannot be empty.";
        priceError.classList.remove('success');
        priceError.classList.add('error');
    } else if (parseFloat(price) <= 0 || !priceRegex.test(price)) {
        priceError.textContent = "The price must be a positive number.";
        priceError.classList.remove('success');
        priceError.classList.add('error');
    } else {
        priceError.textContent = "The price is valid";
        priceError.classList.remove('error');
        priceError.classList.add('success');
    }
});
    </script>
</html>