<?php
include 'C:\xampp\htdocs\web2\Controler\product.php';
include 'C:\xampp\htdocs\web2\Model\addproduct.php';
include 'C:\xampp\htdocs\web2\Controler\categorie.php';
include 'C:\xampp\htdocs\web2\Model\addcategorie.php';
/*include "../web2/Model/addcategorie.php";*/
/*include "../web2/Controler/categorie.php";*/

if(isset($_POST["pName"]) && isset($_POST["pdescription"]) && isset($_POST["price"] ) && isset($_POST["category"]) )
{
    if (
        !empty($_POST["pName"]) && !empty($_POST["pdescription"]) && !empty($_POST["price"]) && !empty($_POST["category"] ) 

    ) {
        $product = new product(null,$_POST["pName"],$_POST["pdescription"],$_POST["price"],$_POST["category"]);
        $productC = new productcontroler();
        $productC->addproduct($product);
        
        header('Location:productlist.php');
    }
}
$categoryc = new categorycontroler();

// Traitement du formulaire
    if (isset($_POST['category']) && isset($_POST['search'])) {
        $id_category =$_POST['category'];
        $l= $categoryc->affichep($id_category);
    }

$category = $categoryc->affichec();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add category</title>
    <link rel="stylesheet" href="styles1.css">
    
    <style>
        .error {
            color: red;
        }
        .success {
            color: green;
        }
        
    </style>
</head>
<body>
<script src="cd.js"></script>
    <header>
        <h1>Add product</h1>
    </header>
    <div class="container">
        <div class="form-box">
            <form method="post" action="">
                <div class="form-group">
                    <label for="pName">product name:</label>
                    <input type="text" id="pName" name="pName">
                    <h5 id="nameError" class="error"> </h5>
                    
                </div>
                <div class="form-group">
                    <label for="pdescription">Description:</label>
                    <input type="text" id="pdescription" name="pdescription">
                    <h5 id="nameError1" class="error"> </h5>
                </div>
                <div class="form-group">
                    <label for="price">price:</label>
                    <input type="float" id="price" name="price">
                    <h5 id="nameError2" class="error"> </h5>
                </div>
                <div class="form-group">
                    <label for="category">select category:</label>
                    <select name="category" id="category">
                    <?php
                    foreach ($category as $c) {
                        echo '<option value="' . $c['id_category'] . '">' . $c['name_category'] . '</option>';
                    }
                    ?>
                    </select>

                </div>
                <div class="form-group">
                    
                    <button type="submit">Enregistrer</button>
                </div>
            </form>
        </div>
    </div>

    <footer>
        <div class="footer-content">
            <p>&copy; 2024 AgriPlate. All rights reserved.</p>
        </div>
    </footer>
    <script src="cd.js"></script>
</body>
</html>