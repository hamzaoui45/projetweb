<?php
include 'C:\xampp\htdocs\web2\Controler\product.php';
include 'C:\xampp\htdocs\web2\Model\addproduct.php';
include 'C:\xampp\htdocs\web2\Controler\categorie.php';
include 'C:\xampp\htdocs\web2\Model\addcategorie.php';

/*$categoryc = new categorycontroler();
$id_category =$_POST['category'];
$l= $categoryc->affichep($id_category);
$categoryp = $categoryc->affichec();*/

//$categoryC = new categorycontroler();
//$list = $categoryC->categoryList();
$order = isset($_POST['order']) && in_array($_POST['order'], ['ASC', 'DESC']) ? $_POST['order'] : 'ASC';

$productC = new productcontroler();
//$list = $productC->productList();
$list = $productC->productListordre($order);
?>










<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> produit </title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>


    <header>
        <img src="logoagriplate.png" alt="Logo" class="top-left-image">
        <div class="container1">
            <h1>Product</h1>
        </div>
        <div class="caret-container">
            <a href="addproduit.php" class="caret-button">
                Add a product
            </a>
        </div>
        <div class="caret-container">
            <a href="addcategory.php" class="caret-button1">
                Add a category
            </a>
        </div>
    </header>
    <div class="a">
    <h1>Our Offers for Sale</h1>
    <p>Discover our best offers exclusively!</p>
    </div>
    <div class="sort-container">
    <form method="POST" action="">
        <label for="order"> prix :</label>
        <select name="order" id="order" onchange="this.form.submit()" class="select-sort">
            <option value="ASC" <?= (isset($order) && $order === 'ASC') ? 'selected' : '' ?>>Croissant</option>
            <option value="DESC" <?= (isset($order) && $order === 'DESC') ? 'selected' : '' ?>>Décroissant</option>
        </select>
    </form>
    </div>

    <section class="offers-container">
    <?php if (isset($list)) { ?>
        <?php foreach ($list as $product) { ?>
            <div class="offer-card">
                <img src="https://via.placeholder.com/300" alt="Produit 1">
                <h2><?= $product['name_product']; ?></h2>
                <p class="description"><?= $product['description']; ?></p>
                <p class="price"><?= $product['price']; ?> dt</p>
                <a href="acheter_produit1.html" class="btn">Acheter</a>
            </div>
        <?php } ?>
    <?php } ?>
</section>

    <footer>
        <div class="container1">
            <p>&copy; 2024 AgriPlate. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>

