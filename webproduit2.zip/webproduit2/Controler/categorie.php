<?php


class categorycontroler
{
    public function addcategory($category)
    {
        $sql = "INSERT INTO category (id_category,name_category,description)
        VALUES (NULL,:name_category,:description)";
        $conn = config::getConnexion();

        /*$categoryName = $category->getName_category();
        if (empty($categoryName)) {
        echo "Category name is empty or null!";}*/

      try {

        $query = $conn->prepare($sql);
        $query->execute([
          'name_category' => $category->getName_category(),
          'description' => $category->getdescription(),
        ]);

        echo "categorie inserted succcefully";
    } catch (Exception $e) {
      die('Erreur: ' . $e->getMessage());
    }
  }
    // select all product list
    public function categoryList()
    {
        $sql = "SELECT * FROM category";
        $conn = config::getConnexion();

        try {
            $liste = $conn->query($sql);
            return $liste;
        } catch (Exception $e) {
            die('Erreur: ' . $e->getMessage());
        }
    }
    function getcategoryById($id)
    {
        $sql = "SELECT * from category where id_category = $id";
        $db = config::getConnexion();
        try {
            $query = $db->prepare($sql);
            $query->execute();

            $category = $query->fetch();
            return $category;
        } catch (Exception $e) {
            die('Error: ' . $e->getMessage());
        }
    }
    function updatecategory($category, $id)
    {
        $db = config::getConnexion();

        $query = $db->prepare(
            'UPDATE category SET 
                name_category = :name_category,
                description =:description
                WHERE id_category = :id_category'
        );
        try {
            $query->execute([
                'id_category' => $id,
                'name_category' => $category->getName_category(),
                'description' =>$category->getdescription(),
            ]);

            echo $query->rowCount() . " records UPDATED successfully <br>";
        } catch (PDOException $e) {
            echo "Error: " . $e->getMessage();
        }
    }
    public function deletecategory($id)
    {
        $sql = "DELETE FROM category WHERE id_category=:id_category";
        $conn = config::getConnexion();
        $req = $conn->prepare($sql);
        $req->bindValue(':id_category', $id);
        try {
            $req->execute();
        } catch (Exception $e) {
            die('Erreur: ' . $e->getMessage());
        }
    }
    public function affichep($id) {
        try {
            $pdo = config::getConnexion();
            $query = $pdo->prepare("SELECT * FROM product WHERE category = :id_category");
            $query->execute(['id_category' => $id]);
            return $query->fetchAll();
        } catch (PDOException $e) {
            echo $e->getMessage();
        }
    }

    public function affichec() {
        try {
            $pdo = config::getConnexion();
            $query = $pdo->prepare("SELECT * FROM category");
            $query->execute();
            return $query->fetchAll();
        } catch (PDOException $e) {
            echo $e->getMessage();
        }
    }

}

?>