<?php
include 'C:\xampp\htdocs\web2\config.php';

class productcontroler
{
    public function addproduct($product)
    {
        $sql = "INSERT INTO product (id_product,name_product,description,price,category)
        VALUES (NULL,:name_product,:description,:price,:category)";
        $conn = config::getConnexion();

      try {

        $query = $conn->prepare($sql);
        $query->execute([
          'name_product' => $product->getName_product(),
          'description' => $product->getDescription(),
          'price'=> $product->getPrice(),
          'category'=> $product->getCategory(),
        ]);

        echo "categorie inserted succcefully";
    } catch (Exception $e) {
      die('Erreur: ' . $e->getMessage());
    }
  }
  public function deleteproduct($id)
    {
        $sql = "DELETE FROM product WHERE id_product=:id_product";
        $conn = config::getConnexion();
        $req = $conn->prepare($sql);
        $req->bindValue(':id_product', $id);
        try {
            $req->execute();
        } catch (Exception $e) {
            die('Erreur: ' . $e->getMessage());
        }
    }
    function updateproduct($product, $id)
    {
        $db = config::getConnexion();

        $query = $db->prepare(
            'UPDATE product SET 
                name_product = :name_product,
                description =:description,
                price=:price,
                category=:category
                WHERE id_product = :id_product'
        );
        try {
            $query->execute([
                'id_product' => $id,
                'name_product' => $product->getName_product(),
                'description' =>$product->getDescription(),
                'price'=>$product->getPrice(),
                'category'=>$product->getCategory(),
            ]);

            echo $query->rowCount() . " records UPDATED successfully <br>";
        } catch (PDOException $e) {
            echo "Error: " . $e->getMessage();
        }
    }
    public function productList()
    {
        $sql = "SELECT * FROM product";
        $conn = config::getConnexion();

        try {
            $liste = $conn->query($sql);
            return $liste;
        } catch (Exception $e) {
            die('Erreur: ' . $e->getMessage());
        }
    }
    function getproductById($id)
    {
        $sql = "SELECT * from product where id_product = $id";
        $db = config::getConnexion();
        try {
            $query = $db->prepare($sql);
            $query->execute();

            $product = $query->fetch();
            return $product;
        } catch (Exception $e) {
            die('Error: ' . $e->getMessage());
        }
    }
    public function productListordre($order = 'ASC') {
        $sql = "SELECT * FROM product ORDER BY price $order"; // 'ASC' pour ordre croissant, 'DESC' pour ordre décroissant
        $db = config::getConnexion();
        try {
            $query = $db->prepare($sql);
            $query->execute();
            return $query->fetchAll();
        } catch (PDOException $e) {
            echo 'Error: ' . $e->getMessage();
        }
    }
    

}